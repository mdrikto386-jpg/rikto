# Top Earn Bd — Supabase + GitHub + Netlify

This is a real backend-connected starter, not a localStorage demo. It includes Supabase Auth, user profiles, task submissions, balance credits after admin approval, and withdrawal requests with admin review.

## 1. Create Supabase project
1. Open https://supabase.com/ and create a free project.
2. In the project dashboard open SQL Editor -> New query.
3. Paste all of `schema.sql` and click Run.
4. Open Project Settings -> API (or API Keys). Copy the Project URL and the `anon` / publishable key.

## 2. Configure the website
1. Open `index.html`.
2. Find `PASTE_YOUR_SUPABASE_PROJECT_URL` and `PASTE_YOUR_SUPABASE_ANON_KEY`.
3. Replace those placeholders with your Project URL and anon/publishable key.
4. Never put a `service_role` or secret key in this file.

## 3. Upload to GitHub
Upload `index.html` to the root of your repository, replacing the old `index.html`. Keep `schema.sql` and this README in the repository if you want a copy of the setup instructions. Commit changes. Netlify should redeploy automatically if it is connected to that repository.

## 4. Make your account Admin
1. Register your own account through the website.
2. In Supabase open Authentication -> Users and copy your user's UUID.
3. In SQL Editor run this command with your real UUID:
   `update public.profiles set role='admin' where id='YOUR_AUTH_USER_UUID';`
4. Log out and log back in. The Admin tab should appear.

## Important
- Use only the Supabase Project URL and anon/publishable key in the frontend. Never expose service-role keys.
- The database policies protect profile balances and admin actions. Admin approval of a task credits the user's balance atomically.
- Withdrawals are requests only. The Admin must manually send the money through the selected provider, then click “Paid & Approve” to deduct the balance and mark the request approved.
- This does not integrate the bKash or Nagad payment API. Automated payouts require an approved merchant/payment-provider integration and secure server-side secrets.
- Configure Supabase Auth email confirmation and production redirect URLs before launch.
- Test with small test accounts first. Review the SQL and security rules before accepting real money or operating a public earning platform.
