-- Top Earn Bd database schema for Supabase
-- Run this entire file in Supabase Dashboard -> SQL Editor -> New query -> Run.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'user' check (role in ('user','admin')),
  balance numeric(12,2) not null default 0 check (balance >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  reward numeric(12,2) not null default 0 check (reward >= 0),
  active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.task_submissions (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id),
  user_id uuid not null references public.profiles(id),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  unique(task_id,user_id)
);

create table if not exists public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  amount numeric(12,2) not null check (amount > 0),
  method text not null check (method in ('bKash','Nagad')),
  wallet text not null check (wallet ~ '^01[0-9]{9}$'),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

-- Create a profile automatically after every successful signup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  insert into public.profiles(id,full_name)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Security-definer helper avoids recursive profiles RLS policy checks.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin');
$$;

alter table public.profiles enable row level security;
alter table public.tasks enable row level security;
alter table public.task_submissions enable row level security;
alter table public.withdrawals enable row level security;

drop policy if exists "profile read self or admin" on public.profiles;
create policy "profile read self or admin" on public.profiles for select to authenticated
using (id=auth.uid() or public.is_admin());

drop policy if exists "profile update self name only" on public.profiles;
create policy "profile update self name only" on public.profiles for update to authenticated
using (id=auth.uid()) with check (id=auth.uid() and role='user' and balance >= 0);
-- Important: clients should not be granted update permission on role/balance.
revoke update on public.profiles from anon, authenticated;
grant update(full_name) on public.profiles to authenticated;
grant select on public.profiles to authenticated;

drop policy if exists "read active tasks or admin" on public.tasks;
create policy "read active tasks or admin" on public.tasks for select to authenticated
using (active=true or public.is_admin());
drop policy if exists "admin insert tasks" on public.tasks;
create policy "admin insert tasks" on public.tasks for insert to authenticated
with check (public.is_admin() and created_by=auth.uid());
drop policy if exists "admin update tasks" on public.tasks;
create policy "admin update tasks" on public.tasks for update to authenticated
using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin delete tasks" on public.tasks;
create policy "admin delete tasks" on public.tasks for delete to authenticated
using (public.is_admin());

drop policy if exists "read own submissions or admin" on public.task_submissions;
create policy "read own submissions or admin" on public.task_submissions for select to authenticated
using (user_id=auth.uid() or public.is_admin());
drop policy if exists "user submit own task" on public.task_submissions;
create policy "user submit own task" on public.task_submissions for insert to authenticated
with check (user_id=auth.uid() and exists(select 1 from public.tasks t where t.id=task_id and t.active=true));
drop policy if exists "admin update submissions" on public.task_submissions;
create policy "admin update submissions" on public.task_submissions for update to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "read own withdrawals or admin" on public.withdrawals;
create policy "read own withdrawals or admin" on public.withdrawals for select to authenticated
using (user_id=auth.uid() or public.is_admin());
drop policy if exists "user create own withdrawal" on public.withdrawals;
create policy "user create own withdrawal" on public.withdrawals for insert to authenticated
with check (user_id=auth.uid() and status='pending');
drop policy if exists "admin update withdrawals" on public.withdrawals;
create policy "admin update withdrawals" on public.withdrawals for update to authenticated
using (public.is_admin()) with check (public.is_admin());

-- Atomic review functions: only an Admin can approve/reject.
create or replace function public.review_task_submission(p_submission_id uuid,p_approve boolean)
returns void language plpgsql security definer set search_path=public
as $$
declare s public.task_submissions%rowtype; r numeric(12,2);
begin
  if not public.is_admin() then raise exception 'Admin permission required'; end if;
  select * into s from public.task_submissions where id=p_submission_id for update;
  if not found or s.status <> 'pending' then raise exception 'Submission not found or already reviewed'; end if;
  if p_approve then
    select reward into r from public.tasks where id=s.task_id;
    update public.profiles set balance=balance+r where id=s.user_id;
    update public.task_submissions set status='approved',reviewed_at=now() where id=s.id;
  else
    update public.task_submissions set status='rejected',reviewed_at=now() where id=s.id;
  end if;
end;
$$;

create or replace function public.review_withdrawal(p_withdrawal_id uuid,p_approve boolean)
returns void language plpgsql security definer set search_path=public
as $$
declare w public.withdrawals%rowtype;
begin
  if not public.is_admin() then raise exception 'Admin permission required'; end if;
  select * into w from public.withdrawals where id=p_withdrawal_id for update;
  if not found or w.status <> 'pending' then raise exception 'Withdrawal not found or already reviewed'; end if;
  if p_approve then
    update public.profiles set balance=balance-w.amount where id=w.user_id and balance>=w.amount;
    if not found then raise exception 'Insufficient user balance'; end if;
    update public.withdrawals set status='approved',reviewed_at=now() where id=w.id;
  else
    update public.withdrawals set status='rejected',reviewed_at=now() where id=w.id;
  end if;
end;
$$;

revoke all on function public.review_task_submission(uuid,boolean) from public;
revoke all on function public.review_withdrawal(uuid,boolean) from public;
grant execute on function public.review_task_submission(uuid,boolean) to authenticated;
grant execute on function public.review_withdrawal(uuid,boolean) to authenticated;

grant select on public.tasks,public.task_submissions,public.withdrawals to authenticated;
grant insert on public.task_submissions,public.withdrawals to authenticated;
grant insert,update,delete on public.tasks to authenticated;
grant update on public.task_submissions,public.withdrawals to authenticated;

-- After signing up your own account, find its UUID in Authentication -> Users.
-- Then run this separately, replacing the UUID:
-- update public.profiles set role='admin' where id='YOUR_AUTH_USER_UUID';
